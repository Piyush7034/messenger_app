const MY_CHAT_UP = "My Chat App";
const LOG_IN_BUTTON = "Login";
const SIGN_UP_BUTTON = "Sign Up";
const ADD_USER = "Add User";
const CAMERA = "Camera";
const CHATS = "Chats";
const STATUS = "Status";
const CONTACTS = "Contacts";